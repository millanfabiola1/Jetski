"use client"

import type React from "react"
import { useEffect, useRef } from "react"
declare global {
  interface Window {
    onYouTubeIframeAPIReady: () => void
    YT: any
  }
}

interface YouTubePlayerProps {
  playlistId: string
}

const YouTubePlayer: React.FC<YouTubePlayerProps> = ({ playlistId }) => {
  const playerRef = useRef<YT.Player | null>(null)

  useEffect(() => {
    // Load the YouTube IFrame Player API code asynchronously
    const tag = document.createElement("script")
    tag.src = "https://www.youtube.com/iframe_api"
    const firstScriptTag = document.getElementsByTagName("script")[0]
    firstScriptTag.parentNode?.insertBefore(tag, firstScriptTag)

    // Create YouTube player when API is ready
    window.onYouTubeIframeAPIReady = () => {
      playerRef.current = new YT.Player("youtube-player", {
        height: "100%",
        width: "100%",
        playerVars: {
          listType: "playlist",
          list: playlistId,
          autoplay: 1,
          controls: 1,
          showinfo: 0,
          modestbranding: 1,
          loop: 1,
          fs: 0,
          cc_load_policy: 0,
          iv_load_policy: 3,
          autohide: 0,
        },
        events: {
          onReady: onPlayerReady,
        },
      })
    }

    return () => {
      if (playerRef.current) {
        playerRef.current.destroy()
      }
    }
  }, [playlistId])

  const onPlayerReady = (event: YT.PlayerEvent) => {
    event.target.playVideo()
  }

  return <div id="youtube-player" className="w-full h-full rounded-lg overflow-hidden" />
}

export default YouTubePlayer

