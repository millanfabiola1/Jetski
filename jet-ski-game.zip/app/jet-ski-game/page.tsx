"use client"

import type React from "react"
import { useEffect, useRef, useState } from "react"
import * as THREE from "three"
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader"
import { Water } from "three/examples/jsm/objects/Water"
import { Sky } from "three/examples/jsm/objects/Sky"
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer"
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass"
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass"
import { Button } from "@/components/ui/button"
import { RotateCw } from "lucide-react"
import YouTubePlayer from "./youtube-player"

// Game variables
let scene: THREE.Scene,
  camera: THREE.PerspectiveCamera,
  renderer: THREE.WebGLRenderer,
  composer: EffectComposer,
  jetSki: THREE.Object3D,
  water: Water,
  hearts: THREE.Object3D[],
  clock: THREE.Clock,
  mixer: THREE.AnimationMixer,
  discoLights: THREE.PointLight[]

const GAME_WIDTH = 100
const GAME_LENGTH = 1000

// Model URLs
const JETSKI_URL = "https://raw.githubusercontent.com/millanfabiola1/3D-models/main/jetski.glb"
const HEART_URL = "https://raw.githubusercontent.com/millanfabiola1/3D-models/main/heart.glb"

// YouTube playlist ID
const PLAYLIST_ID = "PLShQydSxjulj9WVrC69PBoJtJAUIZKraY"

const JetSkiGame: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null)
  const [score, setScore] = useState(0)
  const [gameState, setGameState] = useState<"start" | "playing" | "end">("start")
  const [isLoading, setIsLoading] = useState(true)
  const [loadingProgress, setLoadingProgress] = useState(0)
  const [discoMode, setDiscoMode] = useState(false)
  const [is360Mode, setIs360Mode] = useState(false)
  const [debugInfo, setDebugInfo] = useState("")

  const cameraOffsetRef = useRef(new THREE.Vector3(0, 5, 10))
  const cameraAngleRef = useRef(0)
  const keysRef = useRef<{ [key: string]: boolean }>({})

  useEffect(() => {
    if (!containerRef.current) return

    // Scene setup
    scene = new THREE.Scene()
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000)
    renderer = new THREE.WebGLRenderer({ antialias: true })
    renderer.setSize(window.innerWidth, window.innerHeight)
    renderer.setPixelRatio(window.devicePixelRatio)
    renderer.toneMapping = THREE.ACESFilmicToneMapping
    containerRef.current.appendChild(renderer.domElement)

    // Post-processing
    composer = new EffectComposer(renderer)
    const renderPass = new RenderPass(scene, camera)
    composer.addPass(renderPass)
    const bloomPass = new UnrealBloomPass(new THREE.Vector2(window.innerWidth, window.innerHeight), 1.5, 0.4, 10)
    composer.addPass(bloomPass)

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6)
    scene.add(ambientLight)
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8)
    directionalLight.position.set(0, 50, 0)
    scene.add(directionalLight)

    // Disco lights
    discoLights = []
    const colors = [0xff0000, 0x00ff00, 0x0000ff, 0xffff00, 0xff00ff, 0x00ffff]
    for (let i = 0; i < 6; i++) {
      const light = new THREE.PointLight(colors[i], 0, 50)
      light.position.set(Math.random() * GAME_WIDTH - GAME_WIDTH / 2, 10, Math.random() * GAME_LENGTH - GAME_LENGTH / 2)
      scene.add(light)
      discoLights.push(light)
    }

    // Skybox
    const sky = new Sky()
    sky.scale.setScalar(10000)
    scene.add(sky)

    const skyUniforms = sky.material.uniforms
    skyUniforms["turbidity"].value = 10
    skyUniforms["rayleigh"].value = 2
    skyUniforms["mieCoefficient"].value = 0.005
    skyUniforms["mieDirectionalG"].value = 0.8

    const sun = new THREE.Vector3()
    const phi = THREE.MathUtils.degToRad(90 - 2)
    const theta = THREE.MathUtils.degToRad(180)
    sun.setFromSphericalCoords(1, phi, theta)
    skyUniforms["sunPosition"].value.copy(sun)

    // Water
    const waterGeometry = new THREE.PlaneGeometry(GAME_WIDTH, GAME_LENGTH)
    water = new Water(waterGeometry, {
      textureWidth: 512,
      textureHeight: 512,
      waterNormals: new THREE.TextureLoader().load(
        "https://raw.githubusercontent.com/mrdoob/three.js/master/examples/textures/waternormals.jpg",
        (texture) => {
          texture.wrapS = texture.wrapT = THREE.RepeatWrapping
        },
      ),
      sunDirection: new THREE.Vector3(),
      sunColor: 0xffffff,
      waterColor: 0x001e0f,
      distortionScale: 3.7,
      fog: scene.fog !== undefined,
    })
    water.rotation.x = -Math.PI / 2
    scene.add(water)

    // Load Models
    const loadingManager = new THREE.LoadingManager()
    loadingManager.onProgress = (url, itemsLoaded, itemsTotal) => {
      setLoadingProgress((itemsLoaded / itemsTotal) * 100)
    }
    loadingManager.onLoad = () => {
      setIsLoading(false)
    }

    const jetSkiLoader = new GLTFLoader(loadingManager)
    jetSkiLoader.load(
      JETSKI_URL,
      (gltf) => {
        jetSki = gltf.scene
        jetSki.scale.set(0.5, 0.5, 0.5)
        jetSki.position.set(0, 0.5, 0)
        scene.add(jetSki)

        // Setup animation if available
        if (gltf.animations.length > 0) {
          mixer = new THREE.AnimationMixer(jetSki)
          const action = mixer.clipAction(gltf.animations[0])
          action.play()
        }
      },
      undefined,
      (error) => {
        console.error("Error loading jet ski:", error)
        // Fallback to basic geometry
        const geometry = new THREE.BoxGeometry(2, 1, 4)
        const material = new THREE.MeshPhongMaterial({ color: 0xff0000 })
        jetSki = new THREE.Mesh(geometry, material)
        jetSki.position.set(0, 0.5, 0)
        scene.add(jetSki)
      },
    )

    // Load Heart model and create hearts
    hearts = []
    const heartLoader = new GLTFLoader(loadingManager)
    heartLoader.load(
      HEART_URL,
      (gltf) => {
        const heartModel = gltf.scene
        createHearts(heartModel)
      },
      undefined,
      (error) => {
        console.error("Error loading heart:", error)
        // Fallback to basic geometry
        const geometry = new THREE.SphereGeometry(0.5, 8, 8)
        const material = new THREE.MeshPhongMaterial({ color: 0xff69b4 })
        const heartModel = new THREE.Mesh(geometry, material)
        createHearts(heartModel)
      },
    )

    // Camera setup
    camera.position.set(0, 5, 10)

    // Clock for consistent animations
    clock = new THREE.Clock()

    // Animation loop
    const animate = () => {
      console.log("Animating")
      requestAnimationFrame(animate)
      const delta = clock.getDelta()

      if (gameState === "playing" && jetSki) {
        updateGame(delta)
      }

      if (mixer) mixer.update(delta)

      water.material.uniforms["time"].value += 1.0 / 60.0

      // Update disco lights
      if (discoMode) {
        discoLights.forEach((light, index) => {
          const time = Date.now() * 0.001
          const intensity = Math.sin(time * 2 + index) * 0.5 + 0.5
          light.intensity = intensity * 2
        })
      }

      composer.render()
    }
    animate()

    // Event listeners
    window.addEventListener("resize", onWindowResize, false)
    document.addEventListener("keydown", onKeyDown)
    document.addEventListener("keyup", onKeyUp)

    // Cleanup
    return () => {
      window.removeEventListener("resize", onWindowResize)
      document.removeEventListener("keydown", onKeyDown)
      document.removeEventListener("keyup", onKeyUp)
      if (containerRef.current) {
        containerRef.current.removeChild(renderer.domElement)
      }
      renderer.dispose()
    }
  }, [gameState, discoMode])

  const onWindowResize = () => {
    camera.aspect = window.innerWidth / window.innerHeight
    camera.updateProjectionMatrix()
    renderer.setSize(window.innerWidth, window.innerHeight)
    composer.setSize(window.innerWidth, window.innerHeight)
  }

  const onKeyDown = (event: KeyboardEvent) => {
    keysRef.current[event.code] = true
    console.log("Key down:", event.code)
    if (event.code === "Enter" && (gameState === "start" || gameState === "end")) {
      startGame()
    } else if (event.code === "KeyR" && gameState === "end") {
      startGame()
    } else if (event.code === "Escape" && gameState === "end") {
      quitGame()
    }
  }

  const onKeyUp = (event: KeyboardEvent) => {
    keysRef.current[event.code] = false
    console.log("Key up:", event.code)
  }

  const startGame = () => {
    setGameState("playing")
    setScore(0)
    setDiscoMode(false)
    if (jetSki) {
      jetSki.position.set(0, 0.5, -GAME_LENGTH / 2)
      jetSki.rotation.set(0, 0, 0)
      console.log("Game started. Jet Ski initial position:", jetSki.position)
      console.log("Game started. Jet Ski initial rotation:", jetSki.rotation)
    }
    resetHearts()
  }

  const resetHearts = () => {
    hearts.forEach((heart) => {
      heart.visible = true
      heart.position.set(
        Math.random() * GAME_WIDTH - GAME_WIDTH / 2,
        1 + Math.random() * 2,
        Math.random() * GAME_LENGTH - GAME_LENGTH / 2,
      )
    })
  }

  const quitGame = () => {
    setGameState("start")
    setDiscoMode(false)
  }

  const updateGame = (delta: number) => {
    if (!jetSki) return
    console.log("Updating game", keysRef.current)
    console.log("Jet Ski Position:", jetSki.position)
    console.log("Jet Ski Rotation:", jetSki.rotation)
    const speed = 30 // Units per second
    const rotationSpeed = 1.5 // Radians per second

    const keys = keysRef.current

    // Rotate jet ski
    if (keys["ArrowLeft"] || keys["KeyA"]) {
      jetSki.rotateX(-rotationSpeed * delta)
    }
    if (keys["ArrowRight"] || keys["KeyD"]) {
      jetSki.rotateY(rotationSpeed * delta)
    }

    // Move jet ski forward
    if (keys["ArrowUp"] || keys["KeyW"]) {
      const direction = new THREE.Vector3(0, 0, -1).applyQuaternion(jetSki.quaternion)
      const movement = direction.multiplyScalar(speed * delta)
      jetSki.position.add(movement)
      console.log("Moving forward:", movement)
    }

    // Jet ski floating effect
    jetSki.position.y = 0.5 + Math.sin(clock.elapsedTime * 2) * 0.1

    // Update camera position
    const cameraOffset = new THREE.Vector3(0, 5, 10).applyQuaternion(jetSki.quaternion)
    camera.position.copy(jetSki.position).add(cameraOffset)
    camera.lookAt(jetSki.position)

    // Update hearts animation
    updateHearts(delta)

    // Check collisions
    hearts.forEach((heart) => {
      if (heart.visible) {
        const distance = heart.position.distanceTo(jetSki.position)
        if (distance < 5) {
          heart.visible = false
          setScore((prevScore) => {
            const newScore = prevScore + 1
            if (newScore % 10 === 0) {
              setDiscoMode(true)
              setTimeout(() => setDiscoMode(false), 5000) // Turn off disco mode after 5 seconds
            }
            return newScore
          })
          // Reposition the collected heart
          heart.position.set(
            Math.random() * GAME_WIDTH - GAME_WIDTH / 2,
            1 + Math.random() * 2,
            Math.random() * GAME_LENGTH - GAME_LENGTH / 2,
          )
          heart.visible = true
        }
      }
    })

    // Wrap around
    if (jetSki.position.x < -GAME_WIDTH / 2) jetSki.position.x = GAME_WIDTH / 2
    if (jetSki.position.x > GAME_WIDTH / 2) jetSki.position.x = -GAME_WIDTH / 2
    if (jetSki.position.z < -GAME_LENGTH) jetSki.position.z = 0
    if (jetSki.position.z > 0) jetSki.position.z = -GAME_LENGTH

    // Update debug info
    setDebugInfo(`
    Jet Ski Position: (${jetSki.position.x.toFixed(2)}, ${jetSki.position.y.toFixed(2)}, ${jetSki.position.z.toFixed(2)})
    Jet Ski Rotation: (${jetSki.rotation.x.toFixed(2)}, ${jetSki.rotation.y.toFixed(2)}, ${jetSki.rotation.z.toFixed(2)})
    Delta Time: ${delta.toFixed(4)}
    Keys Pressed: ${Object.entries(keys)
      .filter(([, value]) => value)
      .map(([key]) => key)
      .join(", ")}
    Game State: ${gameState}
  `)
    console.log("Updated Jet Ski Position:", jetSki.position)
    console.log("Updated Jet Ski Rotation:", jetSki.rotation)
  }

  const toggle360Mode = () => {
    setIs360Mode(!is360Mode)
  }

  return (
    <div className="w-full h-screen relative">
      <div ref={containerRef} className="w-full h-full" />
      {isLoading ? (
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center text-white font-['Papyrus']">
          <h2 className="text-2xl mb-4">Loading...</h2>
          <div className="w-64 h-2 bg-gray-700 rounded-full">
            <div
              className="h-full bg-white rounded-full transition-all duration-300"
              style={{ width: `${loadingProgress}%` }}
            />
          </div>
        </div>
      ) : (
        <>
          <div className="absolute top-5 left-5 text-black text-2xl font-['Papyrus']">Score: {score}</div>
          <div className="absolute top-5 left-1/2 transform -translate-x-1/2 text-black text-4xl font-['Papyrus']">
            I LOVE YOU SAM
          </div>
          <div className="absolute bottom-5 left-1/2 transform -translate-x-1/2 flex gap-4">
            <Button onClick={startGame} disabled={gameState === "playing"}>
              {gameState === "start" ? "Start" : "Restart"}
            </Button>
            <Button onClick={quitGame} disabled={gameState !== "playing"}>
              Quit
            </Button>
          </div>
          <Button
            className="absolute top-5 right-5"
            onClick={toggle360Mode}
            variant={is360Mode ? "default" : "outline"}
          >
            <RotateCw className="mr-2 h-4 w-4" /> 360° View
          </Button>
          {gameState === "start" && (
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center text-white font-['Papyrus']">
              <h1 className="text-4xl font-bold mb-4">I LOVE YOU SAM</h1>
              <p className="mb-2">Collect hearts to win!</p>
              <p className="mb-2">Use arrow keys or WASD to steer</p>
              <p className="mb-2">Toggle 360° view for a different perspective</p>
              <p className="text-xl font-bold">Press Start to begin</p>
            </div>
          )}
          {gameState === "end" && (
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center text-white font-['Papyrus']">
              <h1 className="text-4xl font-bold mb-4">Game Over!</h1>
              <p className="text-2xl mb-4">Final Score: {score}</p>
              <p className="text-xl font-bold">Press Restart to play again</p>
            </div>
          )}
          {gameState === "playing" && (
            <div className="absolute bottom-20 right-5 w-64 h-36">
              <YouTubePlayer playlistId={PLAYLIST_ID} />
            </div>
          )}
          <div className="absolute bottom-5 left-5 text-white text-sm font-mono whitespace-pre-wrap">{debugInfo}</div>
        </>
      )}
    </div>
  )
}

function createHearts(model: THREE.Object3D) {
  for (let i = 0; i < 20; i++) {
    const heart = model.clone()
    heart.scale.set(1.2, 1.2, 1.2) // Increased from 0.3 to 1.2 for jumbo hearts
    heart.position.set(
      (Math.random() * GAME_WIDTH) / 2 - GAME_WIDTH / 4, // Reduced range
      1 + Math.random() * 2,
      (Math.random() * GAME_LENGTH) / 2 - GAME_LENGTH / 4, // Reduced range
    )
    // Set the rotation pivot to the center of the heart
    const box = new THREE.Box3().setFromObject(heart)
    const center = box.getCenter(new THREE.Vector3())
    heart.position.sub(center)
    const pivot = new THREE.Group()
    pivot.add(heart)
    pivot.position.copy(center)
    // Add animation parameters
    ;(pivot as any).spinSpeed = Math.random() * 0.5 + 0.5 // Increased spin speed
    ;(pivot as any).bounceSpeed = Math.random() * 2 + 1
    ;(pivot as any).bounceHeight = Math.random() * 0.5 + 0.25
    ;(pivot as any).initialY = pivot.position.y
    scene.add(pivot)
    hearts.push(pivot)
  }
}

function updateHearts(delta: number) {
  hearts.forEach((pivot) => {
    // Spin the heart around its center
    pivot.rotation.y += (pivot as any).spinSpeed * delta

    // Bounce the heart
    const bounceOffset = Math.sin(clock.elapsedTime * (pivot as any).bounceSpeed) * (pivot as any).bounceHeight
    pivot.position.y = (pivot as any).initialY + bounceOffset
  })
}

export default JetSkiGame

